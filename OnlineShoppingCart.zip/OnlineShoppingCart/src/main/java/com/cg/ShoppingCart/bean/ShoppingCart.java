package com.cg.ShoppingCart.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ShoppingCart")
public class ShoppingCart {

	@Id
	@Column(name="cartId")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cart_seq")
	@SequenceGenerator(sequenceName = "cart_sequence", allocationSize = 1, name = "cart_seq")
	private Integer cartId;
	private int customerId;
	private int bookId;
	private int quantity;
	private  Float price;
	
   
	public ShoppingCart( int customerId, int bookId, int quantity, Float price) {
		super();
		
		this.customerId = customerId;
		this.bookId = bookId;
		this.quantity = quantity;
		this.price = price;
	}
	public ShoppingCart() {
		// TODO Auto-generated constructor stub
	}
	public Float getPrice() {
		return price;
	}
	public Integer getCartId() {
		return cartId;
	}
	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	
	
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "ShoppingCart [cartId=" + cartId + ", customerId=" + customerId + ", bookId=" + bookId + ", quantity="
				+ quantity + ", price=" + price + "]";
	}
	
	
}
