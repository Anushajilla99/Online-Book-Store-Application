package com.cg.ShoppingCart.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ShoppingCart.bean.CustomerInfo;

public interface CustomerDao extends JpaRepository<CustomerInfo, Integer>{

}
