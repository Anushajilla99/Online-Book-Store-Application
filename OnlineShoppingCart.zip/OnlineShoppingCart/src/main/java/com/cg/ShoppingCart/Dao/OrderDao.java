package com.cg.ShoppingCart.Dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ShoppingCart.bean.BookInfo;
import  com.cg.ShoppingCart.bean.CustomerInfo;
import  com.cg.ShoppingCart.bean.OrderInfo;

@Repository
public class OrderDao {
	
	@PersistenceContext
	EntityManager em;
	
	public boolean deleteOrder(Integer orderId) {
		OrderInfo order = em.find(OrderInfo.class, orderId);
		if (order != null) {
			em.remove(order);
			return true;
		} else {
			return false;
		}
	}
	
	public CustomerInfo getCustomer(Integer customerId) {
		String str="SELECT customer FROM CustomerInfo customer WHERE customer.customerId="+customerId;
		TypedQuery<CustomerInfo> query=em.createQuery(str, CustomerInfo.class);
		return query.getSingleResult();
	}
	
	public ArrayList<OrderInfo> getAllOrder() {
		String str = "SELECT orderInfo FROM OrderInfo orderInfo";
		TypedQuery<OrderInfo> query = em.createQuery(str, OrderInfo.class);
		return (ArrayList<OrderInfo>) query.getResultList();
	}
	
	public OrderInfo getOrder(Integer orderId) {
		// TODO Auto-generated method stub
			String str = "SELECT orderInfo FROM OrderInfo orderInfo WHERE orderInfo.orderId="
					+ orderId;
			TypedQuery<OrderInfo> query = em.createQuery(str, OrderInfo.class);
			return query.getSingleResult();
		}

	public boolean removeBook(Integer bookId) {
		// TODO Auto-generated method stub
		BookInfo bookInfo = em.find(BookInfo.class, bookId);
		if (bookInfo != null) {
			em.remove(bookInfo);
			return true;
		} else {
			return false;
		}
	}
	
	public boolean addBook(Integer orderId, BookInfo bookInfo) {
		OrderInfo orderInfo = em.find(OrderInfo.class, orderId);
		String title = bookInfo.getTitle();
		String author = bookInfo.getAuthor();
		String description= bookInfo.getDescription();
		Long isbn=bookInfo.getIsbn();
		Float price=bookInfo.getPrice();
		LocalDate publishDate=bookInfo.getPublishDate();
		List<BookInfo> bookList = orderInfo.getBookInfo();

		for (BookInfo t : bookList) {
			if (t.getTitle().equalsIgnoreCase(title)) {
				return false;
			}
		}
		bookInfo.setTitle(title);
		bookInfo.setAuthor(author);
		bookInfo.setDescription(description);
		bookInfo.setIsbn(isbn);
		bookInfo.setPrice(price);
		bookInfo.setPublishDate(publishDate);

        orderInfo.getBookInfo().add(bookInfo);
		em.persist(orderInfo);
		return true;

	}

}
