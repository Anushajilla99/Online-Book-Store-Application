package com.cg.ShoppingCart.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ShoppingCart.bean.BookInfo;
public interface BookDao extends JpaRepository<BookInfo, Integer>{

}
