package com.cg.ShoppingCart.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ShoppingCart.Exceptions.IdNotFoundException;
import com.cg.ShoppingCart.bean.ShoppingCart;
import com.cg.ShoppingCart.service.ShoppingCartService;


@RestController
public class ShoppingCartController {
	
	@Autowired
	private ShoppingCartService service;
	
	@PostMapping("/addToCart")
	public String addToCart(@RequestBody ShoppingCart cart)
	{
		return service.addToCart(cart);				
	}

	@PostMapping("/deleteFromCart")
	public String deleteFromCart(@RequestBody ShoppingCart cart)
	{
		return service.deleteFromCart(cart);
	}
	 
	}

