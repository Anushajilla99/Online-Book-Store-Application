package com.cg.ShoppingCart.Dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ShoppingCart.bean.ShoppingCart;
@Repository
public interface ShoppingCartDao1 extends JpaRepository<ShoppingCart,String>
{

	public List<ShoppingCart> findByCustomerId(int customerId);
	public List<ShoppingCart> findByCustomerIdAndBookId(int customerId,int bookId);

}
