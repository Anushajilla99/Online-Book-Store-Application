package com.cg.ShoppingCart.service;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ShoppingCart.Dao.BookDao;
import com.cg.ShoppingCart.Dao.CustomerDao;
import com.cg.ShoppingCart.Dao.ShoppingCartDao1;
import com.cg.ShoppingCart.Exceptions.IdNotFoundException;
import com.cg.ShoppingCart.bean.BookInfo;
import com.cg.ShoppingCart.bean.ShoppingCart;
@Service
public class ShoppingCartService {
	@Autowired
	BookDao bdao;
	@Autowired
	CustomerDao cdao;
	@Autowired
	ShoppingCartDao1 sdao;

	public void setBdao(BookDao bdao) { this.bdao=bdao;} 
	public void setCdao(CustomerDao cdao){this.cdao=cdao;}
	public void setSdao(ShoppingCartDao1 sdao) {this.sdao = sdao;}
	@Transactional
	public String addToCart(ShoppingCart shoppingcart)
	{
		List<ShoppingCart> cart = sdao.findByCustomerIdAndBookId(shoppingcart.getCustomerId(), shoppingcart.getBookId());
		Optional<BookInfo> binfo=bdao.findById(shoppingcart.getBookId());
		Float price=binfo.get().getPrice();
		if(cart.isEmpty())
		{
			shoppingcart.setQuantity(1);
			shoppingcart.setPrice(price);
			sdao.save(shoppingcart);
			return "Sucessfully added to cart";
		}
		else
		{
			ShoppingCart record=cart.get(0);
			int quantity=record.getQuantity();
			record.setQuantity(quantity+1);
			record.setPrice(price*record.getQuantity());
			sdao.save(record);
			return "Sucessfully added to cart";	
		}
	}
	@Transactional
	public String deleteFromCart(ShoppingCart shoppingcart) throws IdNotFoundException
	{
		try
		{
			List<ShoppingCart> cart = sdao.findByCustomerIdAndBookId(shoppingcart.getCustomerId(), shoppingcart.getBookId());
			Optional<BookInfo> binfo=bdao.findById(shoppingcart.getBookId());
			Float price=binfo.get().getPrice();
			ShoppingCart record=cart.get(0);
			int quantity=record.getQuantity();
			if(quantity==1) {

				sdao.delete(record);
				return "Successfully deleted from cart";
			}
			else {

				record.setQuantity(quantity-1);
				record.setPrice(price*record.getQuantity());
				sdao.save(record);
				return "Sucessfully deleted from cart";
			}
		}
		catch(NoSuchElementException ne)
		{
			throw new IdNotFoundException(ne.getMessage());
		}

	}
}


