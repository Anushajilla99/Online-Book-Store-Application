package com.cg.ShoppingCartTest;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.VerificationCollector;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cg.ShoppingCart.Dao.ShoppingCartDao1;
import com.cg.ShoppingCart.bean.ShoppingCart;
import com.cg.ShoppingCart.service.ShoppingCartService;
@RunWith(SpringJUnit4ClassRunner.class)
public class ShoppindCartTests {

	@Rule
	public VerificationCollector verificationCollector = MockitoJUnit.collector();
	@Mock
	private ShoppingCartDao1 sdao;
//	@Mock
//	private BookDao bookDao;
	//@InjectMocks
	@Mock
	private ShoppingCartService Service;
	@Before
	public void setup(){
		MockitoAnnotations.initMocks(this);
	}
	@Test
	public void testdeleteFromCart_pos1(){
		ShoppingCart s=new  ShoppingCart(1,1,3,200f);
		// Run the test
		Service.deleteFromCart(s);
		// Verify the results
		verify(Service, times(1)).deleteFromCart(s);
	}
	
}
