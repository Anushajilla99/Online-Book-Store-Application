package com.cg.ShoppingCart;

import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.test.web.client.TestRestTemplate;

import org.springframework.test.context.junit4.SpringRunner;

import com.cg.ShoppingCart.bean.ShoppingCart;
import com.cg.ShoppingCart.service.ShoppingCartService;

@RunWith(SpringRunner.class)
	//@SpringBootTest
	@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
	class OnlineShoppingCartApplicationTests { 
	
	@Autowired
	TestRestTemplate testRestTemplate;
	public void setTestRestTemplate(TestRestTemplate testRestTemplate)
	{
		this.testRestTemplate=testRestTemplate;
	}
	
	@LocalServerPort
	int localServerPort;
	@MockBean
	private ShoppingCartService service;
	@Test
	public void testaddToCart() {
		ShoppingCart s=new  ShoppingCart(1,1,3,200f);
		 
		 when(service.addToCart(s)).thenReturn("successfully added to cart");
		}
	
	@Test
	public void testdeleteFromCart() {
		ShoppingCart s=new ShoppingCart();
		 s.setBookId(2);
		 s.setCustomerId(1);
		 when(service.deleteFromCart(s)).thenReturn("successfully deleted from cart");
		}

	@Test
	public void testaddToCart_Positive() throws Exception
	{
		String url="http://localhost:"+localServerPort+"/addToCart";
		ShoppingCart s=new  ShoppingCart(1,1,3,200f);
		ResponseEntity<String> response=testRestTemplate.postForEntity(url, s, String.class);
		Assertions.assertEquals(200, response.getStatusCodeValue());
	}
	
	@Test
	public void testdeleteFromCart_Positive() throws Exception
	{
		String url="http://localhost:"+localServerPort+"/deleteFromCart";
		ShoppingCart s=new  ShoppingCart(1,2,1,200f);
		ResponseEntity<String> response=testRestTemplate.postForEntity(url, s, String.class);
		Assertions.assertEquals(200, response.getStatusCodeValue());
	}
	@Test
	public void testaddToCart_Negative() throws Exception
	{
		String url="http://localhost:"+localServerPort+"/addToCart";
		ShoppingCart s=new  ShoppingCart();
		ResponseEntity<String> response=testRestTemplate.postForEntity(url, s, String.class);
		Assertions.assertEquals(200, response.getStatusCodeValue());
	}
	@Test
	public void testdeleteFromCart_Negative() throws Exception
	{
		String url="http://localhost:"+localServerPort+"/deleteFromCart";
		ShoppingCart s=new  ShoppingCart();
		ResponseEntity<String> response=testRestTemplate.postForEntity(url, s, String.class);
		Assertions.assertEquals(200, response.getStatusCodeValue());
	}
	
}
