import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, ShoppingCart } from 'myservice.service';

@Component({
  selector: 'app-cartform',
  templateUrl: './cartform.component.html',
  styleUrls: ['./cartform.component.css']
})
export class CartformComponent implements OnInit {

  constructor(private service: MyserviceService, private router: Router) { }
  customerId: number;
  ShoppingCarts: ShoppingCart[];
  transac: any;
  message: String
  result: string;
  ngOnInit(): void {
  }
  getCart() {
 this.router.navigate(['/cart'], { queryParams: { customerId: this.customerId} });
     
  }
}
