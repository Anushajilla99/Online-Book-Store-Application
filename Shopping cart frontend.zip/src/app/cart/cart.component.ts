import { Component, OnInit } from '@angular/core';

import {ActivatedRoute } from '@angular/router';
import { ShoppingCart, MyserviceService } from 'myservice.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public Id:number;
  message: string;
  cartSize:number;
  customerId: number;
  cartArray: ShoppingCart[];
  transac: any;
  result: string;
  totalPrice:number=0;
  constructor(private service: MyserviceService,private route:ActivatedRoute) {
  }
  ngOnInit(): any  {

    this.route.queryParams.subscribe( params => {
      this.Id=params.customerId;
      console.log('customerId', this.Id);
      console.log('cartArray', JSON.stringify(this.cartArray));
      this.getCart(this.Id) ;
     
    });
   
  }
  getCart(customerId:number) {

    this.service.viewCart(customerId).subscribe((data) => {
      this.transac = data;
      this.cartArray = this.transac;
      this.cartSize=this.cartArray.length;
      console.log('cartArray', this.cartArray);
      if (this.transac == 0) {
        console.log("null values");
        alert("No cartArray Present!!");
      }
      else {
        console.log("not null values");
        console.log('cartArray', (this.cartArray));
      }
      for (let shoppingCart of this.cartArray) {
        console.log(shoppingCart.price);    
        this.totalPrice=this.totalPrice+shoppingCart.price;
      }
    });
  }

  deleteFromCart(cart:ShoppingCart){
    this.service.deleteFromCart(cart).subscribe(data => {
      this.message=data});
      location.reload();
  }
  addToCart(cart:ShoppingCart){
    this.service.addToCart(cart).subscribe(data => {
      this.message=data});
      location.reload();
  }
  deleteCart(cart:ShoppingCart){
    this.service.deleteCart(cart).subscribe(data => {
      this.message=data});
      location.reload();
  }
}


